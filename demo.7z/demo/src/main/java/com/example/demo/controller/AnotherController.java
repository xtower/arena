package com.example.demo.controller;

import com.example.demo.domain.Counter;
import com.example.demo.domain.Info;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AnotherController {
  @Autowired
  Counter counter;

  @GetMapping(path = "/helloJson2")
  public String helloJSON2(){
    return "Hello ++" + counter.count();
  }
}

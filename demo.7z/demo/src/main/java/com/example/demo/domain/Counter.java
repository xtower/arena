package com.example.demo.domain;

import org.springframework.stereotype.Component;

@Component
public class Counter {
  private int c;

  public Counter (){
    c = 0;
  }

  public int count(){
    this.c ++ ;
    return this.c;
  }

  public int getValue(){
    return this.c;
  }
}

package com.example.demo.controller;

import com.example.demo.domain.Counter;
import com.example.demo.domain.Info;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

  @Autowired
  Counter counter;

  @RequestMapping(path = "/helloc")
  public String hello(){
    return "Hello ";
  }

  @RequestMapping(path = "/hello")
  public String hello(@RequestParam(name = "n", required = false, defaultValue = "Mietek") String name){
    return "Hello " + name;
  }

  @RequestMapping(path = "/helloPost", method = RequestMethod.POST)
  public String helloPost(@RequestParam(name = "n", required = false, defaultValue = "Mietek") String name){
    return "Hello " + name;
  }

  @RequestMapping(path = "/helloJson", method = RequestMethod.POST)
  public String helloJSON(@RequestBody() Info info){
    return "Hello " + info.b;
  }

  @GetMapping(path = "/helloJson")
  public Info helloJSON(){
    Info i = new Info();

    i.a = counter.count();
    i.b = 99;

    return i;
  }
}

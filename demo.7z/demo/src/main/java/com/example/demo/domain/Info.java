package com.example.demo.domain;

public class Info {

  public int a;
  public int b;
  public int c;
}
